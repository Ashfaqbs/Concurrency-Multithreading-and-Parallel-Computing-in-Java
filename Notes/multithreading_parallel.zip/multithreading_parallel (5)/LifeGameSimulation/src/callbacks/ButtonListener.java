package callbacks;

public interface ButtonListener {
	public void startClicked();
	public void restartClicked();
}
