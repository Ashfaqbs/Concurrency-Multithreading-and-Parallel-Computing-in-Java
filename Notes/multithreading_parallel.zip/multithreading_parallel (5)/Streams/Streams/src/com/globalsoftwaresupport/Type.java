package com.globalsoftwaresupport;

public enum Type {
	NOVEL, FICTION, HISTORY, THRILLER, PHILOSOPHY;
}
