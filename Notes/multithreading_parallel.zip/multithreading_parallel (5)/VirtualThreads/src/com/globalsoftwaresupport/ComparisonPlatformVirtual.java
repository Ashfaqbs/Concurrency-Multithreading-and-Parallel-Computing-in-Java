package com.globalsoftwaresupport;

import java.time.Duration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;

public class ComparisonPlatformVirtual {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		
		for(int i=0;i<10000000;i++) {
			
		}
			
	}

	
}
